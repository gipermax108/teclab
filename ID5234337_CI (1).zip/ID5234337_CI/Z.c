#include <stdio.h>

void main() { 
  system("chcp 1251 > nul");
    
  char c, d = '\0';
  int a = 0, b = 0, n = 0, s = 1;
  do {
    d = c;  
    c = getch();
    printf("%c", c);
    n++;
    switch (c) {
      case '-': {
        if (n != 1 || a == 1) {
          s = 0;
        }
        a = 1;
        break;
      }
      case '.':
      case ',': {
        if (n == 1 || d == '-' || b == 1) {
          s = 0;
        }
        b = 1;        
        break;
      }
      default: {        
        if ((c < '0' || c > '9') && c != '\0') {
          s = 0;
        }
        break;
      }
    }    
  } while (c != '\0'); //����� �� End
  n--;
  if (s == 1 && n > 0) {
    if ((n > 1) || (n == 1 && a != 1)) {
      printf("\nYes\n\n");
    }
    else {
      printf("\nNo\n\n");
    }
  }
  else {
    printf("\nNo\n\n");
  }
}
